# DistClassiPy
A python package for a distance-based classifier which can use several different distance metrics.
